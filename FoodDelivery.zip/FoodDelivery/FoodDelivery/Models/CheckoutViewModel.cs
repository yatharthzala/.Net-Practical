﻿using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    public class CheckoutViewModel
    {
        [Required]
        [StringLength(300)]
        public string Address { get; set; } = "";


        [Required]
        public string PaymentMethod { get; set; }
            = "Cash on Delivery";


        public string UserMobile { get; set; } = "";


        public List<CartItem> CartItems { get; set; }
            = new List<CartItem>();


        public decimal Subtotal
        {
            get
            {
                return CartItems.Sum(x => x.Total);
            }
        }


        public decimal DeliveryCharge
        {
            get
            {
                return CartItems.Any()
                    ? 40
                    : 0;
            }
        }


        public decimal Total
        {
            get
            {
                return Subtotal + DeliveryCharge;
            }
        }
    }
}