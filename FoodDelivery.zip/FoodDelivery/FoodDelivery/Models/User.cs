﻿using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    public class User
    {
        public int UserId { get; set; }


        [Required]
        public string Name { get; set; } = "";


        [Required]
        [EmailAddress]
        public string Email { get; set; } = "";


        [Required]
        public string Mobile { get; set; } = "";


        [Required]
        public string Password { get; set; } = "";


        public string Role { get; set; }
            = "Customer";
    }
}