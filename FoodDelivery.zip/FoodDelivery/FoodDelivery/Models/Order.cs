﻿using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    public class Order
    {
        public int OrderId { get; set; }

        public int UserId { get; set; }

        public User? User { get; set; }

        public DateTime OrderDate { get; set; }

        public decimal TotalAmount { get; set; }

        [Required]
        public string Address { get; set; } = "";

        [Required]
        public string Mobile { get; set; } = "";

        [Required]
        public string PaymentMethod { get; set; } = "";

        public string Status { get; set; } = "Placed";

        public ICollection<OrderDetail> OrderDetails { get; set; }
            = new List<OrderDetail>();
    }
}