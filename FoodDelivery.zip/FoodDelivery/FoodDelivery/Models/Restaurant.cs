﻿using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    public class Restaurant
    {
        public int RestaurantId { get; set; }

        [Required]
        public string Name { get; set; } = "";

        public string Description { get; set; } = "";

        public string Category { get; set; } = "";

        public decimal Rating { get; set; }

        public string Image { get; set; } = "";

        public ICollection<Product> Products { get; set; }
            = new List<Product>();
    }
}