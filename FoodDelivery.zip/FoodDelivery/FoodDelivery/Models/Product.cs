﻿using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required]
        public string Name { get; set; } = "";

        public string Description { get; set; } = "";

        public decimal Price { get; set; }

        public string Category { get; set; } = "";

        public string Image { get; set; } = "";

        public int RestaurantId { get; set; }

        public Restaurant? Restaurant { get; set; }
    }
}