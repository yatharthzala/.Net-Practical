﻿using FoodDelivery.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Controllers
{
    public class RestaurantController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RestaurantController(ApplicationDbContext context)
        {
            _context = context;
        }


        // =====================================================
        // ALL RESTAURANTS
        // =====================================================

        public IActionResult Index(string? search)
        {
            var query = _context.Restaurants
                .Include(r => r.Products)
                .AsQueryable();


            // Search restaurant name,
            // description, category or product name

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();

                query = query.Where(r =>
                    r.Name.Contains(search) ||
                    r.Description.Contains(search) ||
                    r.Category.Contains(search) ||
                    r.Products.Any(p =>
                        p.Name.Contains(search) ||
                        p.Category.Contains(search))
                );
            }


            var restaurants = query
                .OrderByDescending(r => r.Rating)
                .ToList();


            ViewBag.Search = search;


            return View(restaurants);
        }


        // =====================================================
        // RESTAURANT MENU
        // =====================================================

        public IActionResult Menu(int id)
        {
            var restaurant = _context.Restaurants
                .Include(r => r.Products)
                .FirstOrDefault(
                    r => r.RestaurantId == id);


            if (restaurant == null)
            {
                return NotFound();
            }


            return View(restaurant);
        }
    }
}