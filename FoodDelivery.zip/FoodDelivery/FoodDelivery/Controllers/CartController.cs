﻿using FoodDelivery.Data;
using FoodDelivery.Extensions;
using FoodDelivery.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodDelivery.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;

        private const string CartKey = "Cart";

        public CartController(ApplicationDbContext context)
        {
            _context = context;
        }


        // =========================
        // CART PAGE
        // =========================

        public IActionResult Index()
        {
            var cart = HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            return View(cart);
        }


        // =========================
        // ADD TO CART
        // =========================

        public IActionResult Add(int productId)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.ProductId == productId);

            if (product == null)
            {
                return NotFound();
            }

            var cart = HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            var existingItem = cart
                .FirstOrDefault(x => x.ProductId == productId);

            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = product.ProductId,
                    ProductName = product.Name,
                    Price = product.Price,
                    Quantity = 1
                });
            }

            HttpContext.Session.SetObject(CartKey, cart);

            return RedirectToAction("Index");
        }


        // =========================
        // INCREASE QUANTITY
        // =========================

        public IActionResult Increase(int productId)
        {
            var cart = HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            var item = cart
                .FirstOrDefault(x => x.ProductId == productId);

            if (item != null)
            {
                item.Quantity++;
            }

            HttpContext.Session.SetObject(CartKey, cart);

            return RedirectToAction("Index");
        }


        // =========================
        // DECREASE QUANTITY
        // =========================

        public IActionResult Decrease(int productId)
        {
            var cart = HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            var item = cart
                .FirstOrDefault(x => x.ProductId == productId);

            if (item != null)
            {
                item.Quantity--;

                if (item.Quantity <= 0)
                {
                    cart.Remove(item);
                }
            }

            HttpContext.Session.SetObject(CartKey, cart);

            return RedirectToAction("Index");
        }


        // =========================
        // REMOVE ITEM
        // =========================

        public IActionResult Remove(int productId)
        {
            var cart = HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            var item = cart
                .FirstOrDefault(x => x.ProductId == productId);

            if (item != null)
            {
                cart.Remove(item);
            }

            HttpContext.Session.SetObject(CartKey, cart);

            return RedirectToAction("Index");
        }
    }
}