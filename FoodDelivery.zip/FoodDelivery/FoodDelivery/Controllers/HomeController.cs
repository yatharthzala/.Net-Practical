using FoodDelivery.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }


        // =========================================
        // HOME PAGE
        // =========================================

        public IActionResult Index()
        {
            var restaurants = _context.Restaurants
                .Include(r => r.Products)
                .OrderByDescending(r => r.Rating)
                .ToList();

            return View(restaurants);
        }


        // =========================================
        // PRIVACY
        // =========================================

        public IActionResult Privacy()
        {
            return View();
        }
    }
}