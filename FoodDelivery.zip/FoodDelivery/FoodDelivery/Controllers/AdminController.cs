﻿using FoodDelivery.Data;
using FoodDelivery.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public AdminController(
            ApplicationDbContext context,
            IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }


        // =====================================================
        // ADMIN DASHBOARD
        // =====================================================

        public IActionResult Index()
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }

            ViewBag.UserCount =
                _context.Users.Count();

            ViewBag.RestaurantCount =
                _context.Restaurants.Count();

            ViewBag.ProductCount =
                _context.Products.Count();

            ViewBag.OrderCount =
                _context.Orders.Count();

            return View();
        }


        // =====================================================
        // RESTAURANTS
        // =====================================================

        public IActionResult Restaurants()
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }

            var restaurants = _context.Restaurants
                .Include(r => r.Products)
                .OrderBy(r => r.Name)
                .ToList();

            return View(restaurants);
        }


        // =====================================================
        // ADD RESTAURANT
        // =====================================================

        [HttpPost]
        public async Task<IActionResult> AddRestaurant(
            string name,
            string description,
            string category,
            decimal rating,
            IFormFile? image)
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            if (string.IsNullOrWhiteSpace(name))
            {
                TempData["Error"] =
                    "Restaurant name is required.";

                return RedirectToAction(
                    "Restaurants");
            }


            // ---------------------------------------------
            // CREATE RESTAURANT
            // ---------------------------------------------

            var restaurant = new Restaurant
            {
                Name = name,
                Description = description ?? "",
                Category = category ?? "",
                Rating = rating,
                Image = ""
            };


            // ---------------------------------------------
            // SAVE IMAGE
            // ---------------------------------------------

            if (image != null &&
                image.Length > 0)
            {
                restaurant.Image =
                    await SaveImage(
                        image,
                        "restaurants");
            }


            _context.Restaurants.Add(restaurant);

            await _context.SaveChangesAsync();


            TempData["Success"] =
                "Restaurant added successfully.";


            return RedirectToAction(
                "Restaurants");
        }


        // =====================================================
        // DELETE RESTAURANT
        // =====================================================

        public async Task<IActionResult> DeleteRestaurant(
            int id)
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var restaurant =
                await _context.Restaurants
                    .Include(r => r.Products)
                    .FirstOrDefaultAsync(
                        r => r.RestaurantId == id);


            if (restaurant == null)
            {
                return NotFound();
            }


            // Delete restaurant image

            DeleteImage(restaurant.Image);


            // Delete product images belonging
            // to this restaurant

            foreach (var product in restaurant.Products)
            {
                DeleteImage(product.Image);
            }


            _context.Restaurants.Remove(restaurant);

            await _context.SaveChangesAsync();


            return RedirectToAction(
                "Restaurants");
        }


        // =====================================================
        // PRODUCTS
        // =====================================================

        public IActionResult Products()
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var products = _context.Products
                .Include(p => p.Restaurant)
                .OrderBy(p => p.Name)
                .ToList();


            ViewBag.Restaurants =
                _context.Restaurants
                .OrderBy(r => r.Name)
                .ToList();


            return View(products);
        }


        // =====================================================
        // ADD PRODUCT
        // =====================================================

        [HttpPost]
        public async Task<IActionResult> AddProduct(
            string name,
            string description,
            decimal price,
            string category,
            int restaurantId,
            IFormFile? image)
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var restaurant =
                await _context.Restaurants
                    .FirstOrDefaultAsync(
                        r => r.RestaurantId == restaurantId);


            if (restaurant == null)
            {
                TempData["Error"] =
                    "Please select a valid restaurant.";

                return RedirectToAction(
                    "Products");
            }


            // ---------------------------------------------
            // CREATE PRODUCT
            // ---------------------------------------------

            var product = new Product
            {
                Name = name ?? "",
                Description = description ?? "",
                Price = price,
                Category = category ?? "",
                RestaurantId = restaurantId,
                Image = ""
            };


            // ---------------------------------------------
            // SAVE IMAGE
            // ---------------------------------------------

            if (image != null &&
                image.Length > 0)
            {
                product.Image =
                    await SaveImage(
                        image,
                        "products");
            }


            _context.Products.Add(product);

            await _context.SaveChangesAsync();


            TempData["Success"] =
                "Product added successfully.";


            return RedirectToAction(
                "Products");
        }


        // =====================================================
        // DELETE PRODUCT
        // =====================================================

        public async Task<IActionResult> DeleteProduct(
            int id)
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var product =
                await _context.Products
                    .FirstOrDefaultAsync(
                        p => p.ProductId == id);


            if (product == null)
            {
                return NotFound();
            }


            DeleteImage(product.Image);


            _context.Products.Remove(product);

            await _context.SaveChangesAsync();


            return RedirectToAction(
                "Products");
        }


        // =====================================================
        // ORDERS
        // =====================================================

        public IActionResult Orders()
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var orders =
                _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderDetails)
                    .ThenInclude(d => d.Product)
                .OrderByDescending(o => o.OrderDate)
                .ToList();


            return View(orders);
        }


        // =====================================================
        // UPDATE ORDER STATUS
        // =====================================================

        [HttpPost]
        public IActionResult UpdateOrderStatus(
            int orderId,
            string status)
        {
            if (!IsAdmin())
            {
                return RedirectToAction(
                    "Index",
                    "Home");
            }


            var order =
                _context.Orders
                .FirstOrDefault(
                    o => o.OrderId == orderId);


            if (order == null)
            {
                return NotFound();
            }


            order.Status = status;

            _context.SaveChanges();


            return RedirectToAction(
                "Orders");
        }


        // =====================================================
        // SAVE IMAGE
        // =====================================================

        private async Task<string> SaveImage(
            IFormFile image,
            string folder)
        {
            // ---------------------------------------------
            // ALLOWED EXTENSIONS
            // ---------------------------------------------

            var allowedExtensions =
                new[]
                {
                    ".jpg",
                    ".jpeg",
                    ".png",
                    ".webp"
                };


            var extension =
                Path.GetExtension(
                    image.FileName)
                .ToLowerInvariant();


            if (!allowedExtensions.Contains(
                extension))
            {
                throw new InvalidOperationException(
                    "Only JPG, JPEG, PNG and WEBP images are allowed.");
            }


            // ---------------------------------------------
            // MAX SIZE = 5 MB
            // ---------------------------------------------

            const long maxSize =
                5 * 1024 * 1024;


            if (image.Length > maxSize)
            {
                throw new InvalidOperationException(
                    "Image size cannot exceed 5 MB.");
            }


            // ---------------------------------------------
            // CREATE DIRECTORY
            // ---------------------------------------------

            var folderPath =
                Path.Combine(
                    _environment.WebRootPath,
                    "images",
                    folder);


            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(
                    folderPath);
            }


            // ---------------------------------------------
            // UNIQUE FILE NAME
            // ---------------------------------------------

            var fileName =
                Guid.NewGuid().ToString("N")
                + extension;


            var filePath =
                Path.Combine(
                    folderPath,
                    fileName);


            // ---------------------------------------------
            // SAVE FILE
            // ---------------------------------------------

            using (
                var stream =
                    new FileStream(
                        filePath,
                        FileMode.Create))
            {
                await image.CopyToAsync(
                    stream);
            }


            // ---------------------------------------------
            // RETURN WEB PATH
            // ---------------------------------------------

            return
                $"/images/{folder}/{fileName}";
        }


        // =====================================================
        // DELETE IMAGE
        // =====================================================

        private void DeleteImage(
            string? imagePath)
        {
            if (string.IsNullOrWhiteSpace(
                imagePath))
            {
                return;
            }


            var cleanPath =
                imagePath
                    .TrimStart('/')
                    .Replace(
                        '/',
                        Path.DirectorySeparatorChar);


            var fullPath =
                Path.Combine(
                    _environment.WebRootPath,
                    cleanPath);


            if (System.IO.File.Exists(
                fullPath))
            {
                System.IO.File.Delete(
                    fullPath);
            }
        }


        // =====================================================
        // ADMIN CHECK
        // =====================================================

        private bool IsAdmin()
        {
            var role =
                HttpContext.Session
                    .GetString("UserRole");

            return role == "Admin";
        }
    }
}