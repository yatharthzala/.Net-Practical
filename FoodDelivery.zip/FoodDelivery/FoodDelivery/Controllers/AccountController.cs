﻿using FoodDelivery.Data;
using FoodDelivery.Models;
using Microsoft.AspNetCore.Mvc;

namespace FoodDelivery.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;


        public AccountController(
            ApplicationDbContext context)
        {
            _context = context;
        }


        // =========================================
        // REGISTER
        // =========================================

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Register(User user)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }


            bool emailExists =
                _context.Users.Any(u =>
                    u.Email == user.Email);


            if (emailExists)
            {
                ViewBag.Error =
                    "An account with this email already exists.";

                return View(user);
            }


            // All newly registered users
            // are customers.

            user.Role = "Customer";


            _context.Users.Add(user);

            _context.SaveChanges();


            return RedirectToAction("Login");
        }


        // =========================================
        // LOGIN
        // =========================================

        [HttpGet]
        public IActionResult Login()
        {
            // If already logged in,
            // don't show login again.

            if (HttpContext.Session
                .GetInt32("UserId") != null)
            {
                string? role =
                    HttpContext.Session
                    .GetString("UserRole");


                if (role == "Admin")
                {
                    return RedirectToAction(
                        "Index",
                        "Admin");
                }


                return RedirectToAction(
                    "Index",
                    "Home");
            }


            return View();
        }


        [HttpPost]
        public IActionResult Login(
            string email,
            string password)
        {
            var user =
                _context.Users.FirstOrDefault(u =>
                    u.Email == email &&
                    u.Password == password);


            if (user == null)
            {
                ViewBag.Error =
                    "Invalid email or password.";

                return View();
            }


            // =====================================
            // SAVE USER INFORMATION IN SESSION
            // =====================================

            HttpContext.Session.SetInt32(
                "UserId",
                user.UserId);


            HttpContext.Session.SetString(
                "UserName",
                user.Name);


            HttpContext.Session.SetString(
                "UserRole",
                user.Role);


            HttpContext.Session.SetString(
                "UserMobile",
                user.Mobile);


            // =====================================
            // REDIRECT BASED ON ROLE
            // =====================================

            if (user.Role == "Admin")
            {
                return RedirectToAction(
                    "Index",
                    "Admin");
            }


            return RedirectToAction(
                "Index",
                "Home");
        }


        // =========================================
        // LOGOUT
        // =========================================

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }
    }
}