﻿using FoodDelivery.Data;
using FoodDelivery.Extensions;
using FoodDelivery.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;

        private const string CartKey = "Cart";

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        // =========================================
        // CHECKOUT - GET
        // =========================================

        [HttpGet]
        public IActionResult Checkout()
        {
            var userId =
                HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            var cart =
                HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            if (!cart.Any())
            {
                return RedirectToAction(
                    "Index",
                    "Cart");
            }

            string mobile =
                HttpContext.Session
                .GetString("UserMobile")
                ?? "";

            var model = new CheckoutViewModel
            {
                CartItems = cart,
                UserMobile = mobile,
                PaymentMethod = "Cash on Delivery"
            };

            return View(model);
        }

        // =========================================
        // CHECKOUT - POST
        // =========================================

        [HttpPost]
        public IActionResult Checkout(
            CheckoutViewModel model)
        {
            var userId =
                HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            var cart =
                HttpContext.Session
                .GetObject<List<CartItem>>(CartKey)
                ?? new List<CartItem>();

            if (!cart.Any())
            {
                return RedirectToAction(
                    "Index",
                    "Cart");
            }

            // Put cart back into the model
            // in case validation fails.
            model.CartItems = cart;

            // Get mobile number from logged-in user
            string mobile =
                HttpContext.Session
                .GetString("UserMobile")
                ?? "";

            model.UserMobile = mobile;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // =====================================
            // CREATE ORDER
            // =====================================

            var order = new Order
            {
                UserId = userId.Value,

                OrderDate = DateTime.Now,

                Address = model.Address,

                // IMPORTANT:
                // Mobile comes from the user's account.
                Mobile = mobile,

                PaymentMethod = model.PaymentMethod,

                Status = "Placed",

                TotalAmount = model.Total
            };

            _context.Orders.Add(order);

            _context.SaveChanges();

            // =====================================
            // CREATE ORDER DETAILS
            // =====================================

            foreach (var item in cart)
            {
                var detail = new OrderDetail
                {
                    OrderId = order.OrderId,

                    ProductId = item.ProductId,

                    Quantity = item.Quantity,

                    Price = item.Price
                };

                _context.OrderDetails.Add(detail);
            }

            _context.SaveChanges();

            // =====================================
            // CLEAR CART
            // =====================================

            HttpContext.Session.Remove(CartKey);

            // =====================================
            // ORDER SUCCESS
            // =====================================

            return RedirectToAction(
                "Success",
                new
                {
                    id = order.OrderId
                });
        }

        // =========================================
        // ORDER SUCCESS
        // =========================================

        public IActionResult Success(int id)
        {
            var userId =
                HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            var order =
                _context.Orders
                .FirstOrDefault(o =>
                    o.OrderId == id &&
                    o.UserId == userId.Value);

            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // =========================================
        // MY ORDERS
        // =========================================

        public IActionResult MyOrders()
        {
            var userId =
                HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            var orders =
                _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(d => d.Product)
                .Where(o =>
                    o.UserId == userId.Value)
                .OrderByDescending(o =>
                    o.OrderDate)
                .ToList();

            return View(orders);
        }
    }
}