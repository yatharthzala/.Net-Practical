using FoodDelivery.Data;
using FoodDelivery.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);


// ==========================================
// DATABASE
// ==========================================

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString(
            "DefaultConnection")));


// ==========================================
// MVC
// ==========================================

builder.Services.AddControllersWithViews();


// ==========================================
// SESSION
// ==========================================

builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);

    options.Cookie.HttpOnly = true;

    options.Cookie.IsEssential = true;
});


var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var context =
        scope.ServiceProvider
            .GetRequiredService<ApplicationDbContext>();

    await OneTimeSeeder.SeedAsync(context);
}

// ==========================================
// DATABASE MIGRATION + SEED
// ==========================================

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider
        .GetRequiredService<ApplicationDbContext>();

    context.Database.Migrate();


    // ======================================
    // CREATE ADMIN ACCOUNT
    // ======================================

    if (!context.Users.Any(u =>
        u.Email == "admin@foodie.com"))
    {
        context.Users.Add(new User
        {
            Name = "Foodie Admin",
            Email = "admin@foodie.com",
            Mobile = "9999999999",
            Password = "admin123",
            Role = "Admin"
        });

        context.SaveChanges();
    }


    // ======================================
    // CREATE RESTAURANTS
    // ======================================

    if (!context.Restaurants.Any())
    {
        var pizzaHub = new Restaurant
        {
            Name = "Pizza Hub",
            Description =
                "Delicious pizzas and Italian food.",
            Category = "Pizza",
            Rating = 4.5m,
            Image = ""
        };


        var burgerHouse = new Restaurant
        {
            Name = "Burger House",
            Description =
                "Fresh and tasty burgers.",
            Category = "Fast Food",
            Rating = 4.3m,
            Image = ""
        };


        var foodCorner = new Restaurant
        {
            Name = "Food Corner",
            Description =
                "Chinese, Indian food and snacks.",
            Category = "Multi Cuisine",
            Rating = 4.4m,
            Image = ""
        };


        context.Restaurants.AddRange(
            pizzaHub,
            burgerHouse,
            foodCorner);

        context.SaveChanges();


        // ==================================
        // PRODUCTS
        // ==================================

        context.Products.AddRange(

            new Product
            {
                Name = "Margherita Pizza",
                Description =
                    "Classic cheese pizza",
                Price = 199,
                Category = "Pizza",
                RestaurantId =
                    pizzaHub.RestaurantId
            },

            new Product
            {
                Name = "Farmhouse Pizza",
                Description =
                    "Loaded vegetable pizza",
                Price = 299,
                Category = "Pizza",
                RestaurantId =
                    pizzaHub.RestaurantId
            },

            new Product
            {
                Name = "Paneer Pizza",
                Description =
                    "Paneer loaded pizza",
                Price = 279,
                Category = "Pizza",
                RestaurantId =
                    pizzaHub.RestaurantId
            },

            new Product
            {
                Name = "Cheese Burger",
                Description =
                    "Fresh cheese burger",
                Price = 149,
                Category = "Burger",
                RestaurantId =
                    burgerHouse.RestaurantId
            },

            new Product
            {
                Name = "Veg Burger",
                Description =
                    "Fresh vegetable burger",
                Price = 129,
                Category = "Burger",
                RestaurantId =
                    burgerHouse.RestaurantId
            },

            new Product
            {
                Name = "Veg Noodles",
                Description =
                    "Spicy vegetable noodles",
                Price = 179,
                Category = "Chinese",
                RestaurantId =
                    foodCorner.RestaurantId
            },

            new Product
            {
                Name = "Veg Manchurian",
                Description =
                    "Crispy Manchurian balls",
                Price = 189,
                Category = "Chinese",
                RestaurantId =
                    foodCorner.RestaurantId
            }
        );

        context.SaveChanges();
    }
}


// ==========================================
// MIDDLEWARE
// ==========================================

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");

    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();


// ==========================================
// DEFAULT ROUTE
// APPLICATION STARTS WITH LOGIN
// ==========================================

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");


app.Run();