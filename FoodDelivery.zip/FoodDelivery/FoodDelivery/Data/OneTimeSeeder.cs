﻿using FoodDelivery.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Data
{
    public static class OneTimeSeeder
    {
        public static async Task SeedAsync(
            ApplicationDbContext context)
        {
            // =====================================================
            // IMPORTANT
            // This is a ONE-TIME seeder.
            //
            // Run the application once.
            // After the data appears in SQL Server,
            // delete this file and remove the call from Program.cs.
            // =====================================================


            // -----------------------------------------------------
            // DO NOT CREATE DUPLICATES
            // -----------------------------------------------------

            if (await context.Restaurants.AnyAsync())
            {
                return;
            }


            // =====================================================
            // RESTAURANT 1
            // =====================================================

            var pizzaHub = new Restaurant
            {
                Name = "Pizza Hub",

                Description =
                    "Delicious pizzas made with fresh ingredients.",

                Category = "Pizza",

                Rating = 4.5m,

                Image =
                    "/images/restaurants/pizzahub.jpg"
            };


            // =====================================================
            // RESTAURANT 2
            // =====================================================

            var burgerHouse = new Restaurant
            {
                Name = "Burger House",

                Description =
                    "Fresh and tasty burgers made to order.",

                Category = "Fast Food",

                Rating = 4.3m,

                Image =
                    "/images/restaurants/burgerhouse.jpg"
            };


            // =====================================================
            // RESTAURANT 3
            // =====================================================

            var foodCorner = new Restaurant
            {
                Name = "Food Corner",

                Description =
                    "Chinese, Indian food and delicious snacks.",

                Category = "Multi Cuisine",

                Rating = 4.4m,

                Image =
                    "/images/restaurants/foodcorner.jpg"
            };


            // =====================================================
            // ADD RESTAURANTS
            // =====================================================

            context.Restaurants.AddRange(
                pizzaHub,
                burgerHouse,
                foodCorner
            );


            await context.SaveChangesAsync();


            // =====================================================
            // PIZZA HUB PRODUCTS
            // =====================================================

            var pizzaProducts = new List<Product>
            {
                new Product
                {
                    Name = "Margherita Pizza",

                    Description =
                        "Classic pizza with tomato sauce and mozzarella cheese.",

                    Price = 199m,

                    Category = "Pizza",

                    Image =
                        "/images/products/margherita.jpg",

                    RestaurantId =
                        pizzaHub.RestaurantId
                },


                new Product
                {
                    Name = "Farmhouse Pizza",

                    Description =
                        "Loaded pizza with fresh vegetables and cheese.",

                    Price = 299m,

                    Category = "Pizza",

                    Image =
                        "/images/products/farmhouse.jpg",

                    RestaurantId =
                        pizzaHub.RestaurantId
                },


                new Product
                {
                    Name = "Paneer Pizza",

                    Description =
                        "Delicious pizza topped with spicy paneer.",

                    Price = 279m,

                    Category = "Pizza",

                    Image =
                        "/images/products/paneer-pizza.jpg",

                    RestaurantId =
                        pizzaHub.RestaurantId
                }
            };


            // =====================================================
            // BURGER HOUSE PRODUCTS
            // =====================================================

            var burgerProducts = new List<Product>
            {
                new Product
                {
                    Name = "Cheese Burger",

                    Description =
                        "Juicy vegetable burger with melted cheese.",

                    Price = 149m,

                    Category = "Burger",

                    Image =
                        "/images/products/cheese-burger.jpg",

                    RestaurantId =
                        burgerHouse.RestaurantId
                },


                new Product
                {
                    Name = "Veg Burger",

                    Description =
                        "Crispy vegetable patty with fresh vegetables.",

                    Price = 129m,

                    Category = "Burger",

                    Image =
                        "/images/products/veg-burger.jpg",

                    RestaurantId =
                        burgerHouse.RestaurantId
                }
            };


            // =====================================================
            // FOOD CORNER PRODUCTS
            // =====================================================

            var foodCornerProducts = new List<Product>
            {
                new Product
                {
                    Name = "Veg Noodles",

                    Description =
                        "Spicy noodles tossed with fresh vegetables.",

                    Price = 179m,

                    Category = "Chinese",

                    Image =
                        "/images/products/veg-noodles.jpg",

                    RestaurantId =
                        foodCorner.RestaurantId
                },


                new Product
                {
                    Name = "Veg Manchurian",

                    Description =
                        "Crispy vegetable balls in delicious Manchurian sauce.",

                    Price = 189m,

                    Category = "Chinese",

                    Image =
                        "/images/products/veg-manchurian.jpg",

                    RestaurantId =
                        foodCorner.RestaurantId
                }
            };


            // =====================================================
            // ADD ALL PRODUCTS
            // =====================================================

            context.Products.AddRange(
                pizzaProducts
                    .Concat(burgerProducts)
                    .Concat(foodCornerProducts)
            );


            await context.SaveChangesAsync();


            // =====================================================
            // CONSOLE MESSAGE
            // =====================================================

            Console.WriteLine(
                "=============================================="
            );

            Console.WriteLine(
                "ONE-TIME FOOD DATA SEED COMPLETED"
            );

            Console.WriteLine(
                "Restaurants and products have been added."
            );

            Console.WriteLine(
                "You can now remove OneTimeSeeder.cs"
            );

            Console.WriteLine(
                "and its call from Program.cs."
            );

            Console.WriteLine(
                "=============================================="
            );
        }
    }
}